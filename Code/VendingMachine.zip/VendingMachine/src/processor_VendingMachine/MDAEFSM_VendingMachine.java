package processor_VendingMachine;

import statePattern.abstractStates;

public class MDAEFSM_VendingMachine {

		public static int k; // No of cups
		public static int A[] = new int[3]; // Additives list
		abstractStates AS; // pointer to abstractStates.
		abstractStates abStates[];

	public void setK(int n) {
		// sets the value of k.
		MDAEFSM_VendingMachine.k = n;
	}

	public int getK() {
		//returns the value of k.
		return k;
	}
	public void setStateList(abstractStates abStates[]) {
		// sets the list of states
		this.abStates = abStates;
		this.AS = abStates[0];

	}

	public void changeState(int index) {
		// change the state and prints the state based on the input.
		this.AS = this.abStates[index];
		System.out.println("State Changed to ");
		switch (index) {
		case 1:
			System.out.println("NoCups");
			break;

		case 2:
			System.out.println("Idle");
			break;

		case 3:
			System.out.println("CoinsInstered");
			break;

		case 0:
			System.out.println("Start");
			break;
		}

	}

	public void Cancel() {
		// call cancel in abstractStates class
		AS.cancel();

	}

	public void set_Price() {
		//SetPrice of abstractStates class is invoked.
		AS.SetPrice();

	}

	public void Insert_cups(int n) {
		//insert_cups of abstractStates class is invoked.
		AS.insert_cups(n);

	}

	public void dispose_drink(int i) {
		//dispose_drink of abstractStates class is invoked.
		AS.dispose_drink(i);

	}

	public void additive(int i) {
		//Additive of abstractStates class is invoked.
		AS.Additive(i);

	}

	public void card() {
		//Card of abstractStates class is invoked.
		AS.Card();

	}

	public void coin(int i) {
		//Coin of abstractStates class is invoked.
		AS.Coin(i);

	}

	public void create() {
		//Create of abstractStates class is invoked.
		AS.Create();

	}

	public void setAtoZero() {
		//sets value of A to zero.
		int len = A.length;
		for (int i = 0; i < len; i++) {
			A[i] = 0;
		}
	}

	public static void updateA(int index, int val) {
		// changes the value of A to given value.
		MDAEFSM_VendingMachine.A[index] = val;
	}

}
