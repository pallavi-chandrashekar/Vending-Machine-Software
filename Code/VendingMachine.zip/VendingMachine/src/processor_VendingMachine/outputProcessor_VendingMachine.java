package processor_VendingMachine;

import abstractFactoryPattern.*;
import data_VendingMachine.dataStore;
import strategyPattern.*;

public class outputProcessor_VendingMachine {
	public static int coinValue_vm1 = 0;
	public static float coinValue_vm2 = 0;

	DisposeAdditiveAbstract DAA; // pointer to DisposeAdditiveAbstract class.
	DisposeDrinkAbstract DDA; // pointer to DisposeDrinkAbstract class.
	IncreaseCFAbstract ICFA; // pointer to IncreaseCFAbstract  class
	ReturnCoinsAbstract RCA; // pointer to ReturnCoinsAbstract class
	StorePriceAbstract SPA; // pointer to StorePriceAbstract class
	ZeroCFAbstract ZCFA; // pointer to ZeroCFAbstract class
	abstractFactory AF; // pointer to abstract factory.
	dataStore DS; // pointer to dataStore.

	public void setDataStore() {
		// get datastore value from abstract factory and sets it to DS.
		DS = AF.getDataStore();

	}

	public void setFactory(abstractFactory obj) {
		// sets the factory object as passed value.
		AF = obj;

	}

	public void StorePrice() {
		//gets StorePrice class object and calls the function StorePrice 
		SPA = AF.getStorePrice_Obj();
		SPA.StorePrice(DS);

	}

	public void ReturnCoins() {
		//gets ReturnCoins class object and calls the function ReturnCoins 
		RCA = AF.getReturnCoins_Obj();
		RCA.ReturnCoins();

	}

	public void ZeroCF() {
		//gets ZeroCF class object and calls the function ZeroCF with DS object.
		ZCFA = AF.getZeroCF_Obj();
		ZCFA.ZeroCF(DS);
	}

	public void IncreaseCF() {
		//gets IncreaseCF class object and calls the function IncreaseCF with DS object. 
		ICFA = AF.getIncreaseCF_Obj();
		ICFA.IncreaseCF(DS);

	}

	public void DisposeDrink(int drink) {
		//gets DisposeDrink class object and calls the function DisposeDrink 
		DDA = AF.getDisposeDrink_Obj();
		DDA.DisposeDrink(drink);

	}

	public void DisposeAdditive(int[] a) {
		//gets DisposeAdditive class object and calls the function DisposeAdditive 
		DAA = AF.getDisposeAdditive_Obj();
		DAA.DisposeAdditive(a);

	}

}
