package abstractFactoryPattern;

import data_VendingMachine.dataStore_vm1;
import strategyPattern.*;

public class abstractFactory_vm1 extends abstractFactory {
	dataStore_vm1 DS; // pointer to dataStore_vm1 class of vm1.
	DisposeAdditive_vm1 DA; // pointer to DisposeAdditive_vm1 class of vm1.
	DisposeDrink_vm1 DD; // pointer to DisposeDrink_vm1 class of vm1.
	IncreaseCF_vm1 ICF; // pointer to IncreaseCF_vm1 class of vm1.
	ReturnCoins_vm1 RC; // pointer to ReturnCoins_vm1 class of vm1.
	StorePrice_vm1 SP; // pointer to StorePrice_vm1 class of vm1.
	ZeroCF_vm1 ZCF; // pointer to ZeroCF_vm1 class of vm1.

	@Override
	public dataStore_vm1 getDataStore() {
		// Method is used to get the dataStore assigned to VendingMachine 1, create object for the datastore and return the dataStore object
		if (DS == null)
			DS = new dataStore_vm1();

		return DS;
	}

	@Override
	public DisposeAdditive_vm1 getDisposeAdditive_Obj() {
		// Method is used to create an object for DisposeAdditive_vm1 class and return the object.
		if (DA == null)
			DA = new DisposeAdditive_vm1();

		return DA;
	}

	@Override
	public DisposeDrink_vm1 getDisposeDrink_Obj() {
		// Method is used to create an object for DisposeDrink_vm1 class and return the object.
		if (DD == null)
			DD = new DisposeDrink_vm1();

		return DD;
	}

	@Override
	public IncreaseCF_vm1 getIncreaseCF_Obj() {
		// Method is used to create an object for IncreaseCF_vm1 class and return the object.
		if (ICF == null)
			ICF = new IncreaseCF_vm1();

		return ICF;
	}

	@Override
	public ReturnCoins_vm1 getReturnCoins_Obj() {
		// Method is used to create an object for to ReturnCoins_vm1 class and return the object.
		if (RC == null)
			RC = new ReturnCoins_vm1();

		return RC;
	}

	@Override
	public StorePrice_vm1 getStorePrice_Obj() {
		// Method is used to create an object for StorePrice_vm1 class and return the object.
		if (SP == null)
			SP = new StorePrice_vm1();

		return SP;
	}

	@Override
	public ZeroCF_vm1 getZeroCF_Obj() {
		// Method is used to create an object for ZeroCF_vm1 class and return the object.
		if (ZCF == null)
			ZCF = new ZeroCF_vm1();

		return ZCF;
	}

}
