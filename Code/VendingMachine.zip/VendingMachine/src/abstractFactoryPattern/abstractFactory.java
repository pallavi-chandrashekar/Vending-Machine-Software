package abstractFactoryPattern;

import data_VendingMachine.*;
import strategyPattern.*;

public abstract class abstractFactory {

	//This is the abstract class of abstract factory pattern. 
	
	public abstract dataStore getDataStore(); //Method is used to get the dataStore assigned to VendingMachine.

	public abstract DisposeAdditiveAbstract getDisposeAdditive_Obj(); // Method is used to create an object for DisposeAdditive class and return the object.

	public abstract DisposeDrinkAbstract getDisposeDrink_Obj(); // Method is used to create an object for DisposeDrink class and return the object.

	public abstract IncreaseCFAbstract getIncreaseCF_Obj(); // Method is used to create an object for IncreaseCF class and return the object.

	public abstract ReturnCoinsAbstract getReturnCoins_Obj(); // Method is used to create an object for to ReturnCoins class and return the object.

	public abstract StorePriceAbstract getStorePrice_Obj(); // Method is used to create an object for StorePrice class and return the object.

	public abstract ZeroCFAbstract getZeroCF_Obj(); // Method is used to create an object for ZeroCF class and return the object.

}
