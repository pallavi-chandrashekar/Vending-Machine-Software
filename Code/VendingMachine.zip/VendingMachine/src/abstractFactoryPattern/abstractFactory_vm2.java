package abstractFactoryPattern;

import data_VendingMachine.dataStore_vm2;
import strategyPattern.*;

public class abstractFactory_vm2 extends abstractFactory {

	dataStore_vm2 DS;
	DisposeAdditive_vm2 DA;
	DisposeDrink_vm2 DD;
	IncreaseCF_vm2 ICF;
	ReturnCoins_vm2 RC;
	StorePrice_vm2 SP;
	ZeroCF_vm2 ZCF;

	public dataStore_vm2 getDataStore() {
		// Method is used to get the dataStore assigned to VendingMachine 2, create object for the datastore and return the dataStore object.
		if (DS == null)
			DS = new dataStore_vm2();

		return DS;
	}

	public DisposeAdditive_vm2 getDisposeAdditive_Obj() {
		// Method is used to create an object for DisposeAdditive_vm2 class and return the object.
		if (DA == null)
			DA = new DisposeAdditive_vm2();

		return DA;
	}

	public DisposeDrink_vm2 getDisposeDrink_Obj() {
		// Method is used to create an object for DisposeDrink_vm2 class and return the object.
		if (DD == null)
			DD = new DisposeDrink_vm2();

		return DD;
	}

	public IncreaseCF_vm2 getIncreaseCF_Obj() {
		// Method is used to create an object for IncreaseCF_vm2 class and return the object.
		if (ICF == null)
			ICF = new IncreaseCF_vm2();

		return ICF;
	}

	public ReturnCoins_vm2 getReturnCoins_Obj() {
		// Method is used to create an object for to ReturnCoins_vm2 class and return the object.
		if (RC == null)
			RC = new ReturnCoins_vm2();

		return RC;
	}

	public StorePrice_vm2 getStorePrice_Obj() {
		// Method is used to create an object for StorePrice_vm2 class and return the object.
		if (SP == null)
			SP = new StorePrice_vm2();

		return SP;
	}

	public ZeroCF_vm2 getZeroCF_Obj() {
		// Method is used to create an object for ZeroCF_vm2 class and return the object.
		if (ZCF == null)
			ZCF = new ZeroCF_vm2();

		return ZCF;
	}

}
