package data_VendingMachine;

public abstract class dataStore {
	//This is the abstract class of dataStore.

	//set and get methods for dataStore_vm1 and dataStore_vm2 
	public abstract void setTemp_p(int p); //Method stores the value passed to temp_p variable dataStore of VM. 
	public abstract int getTemp_p(); // Method is used to get the value of temp_p variable of dataStore of VM.
	public abstract void setPrice(int price); //Method stores the value passed to price variable of dataStore of VM. 
	public abstract int getPrice();// Method is used to get the value of price variable of dataStore of VM.
	public abstract void setTemp_v(int v); //Method stores the value passed to temp_v variable of dataStore of VM. 
	public abstract int getTemp_v();// Method is used to get the value of temp_v variable of dataStore of VM.
	public abstract void setCF(int cf); //Method stores the value passed to cf variable of dataStore of VM.
	public abstract int getCF();// Method is used to get the value of cf variable of dataStore of VM
	

	public abstract void setTemp_p1(float p); //Method stores the value passed to temp_p variable of dataStore of VM. 
	public abstract float getTemp_p1();// Method is used to get the value of temp_p variable of dataStore of VM.
	public abstract void setPrice1(float price); //Method stores the value passed to price variable of dataStore of VM.
	public abstract float getPrice1();// Method is used to get the value of price variable of dataStore of VM.
	public abstract void setTemp_v1(float v); //Method stores the value passed to temp_v variable of dataStore of VM.
	public abstract float getTemp_v1();// Method is used to get the value of temp_v variable of dataStore of VM.
	public abstract void setCF1(float cf); //Method stores the value passed to temp_p variable of dataStore of VM.
	public abstract float getCF1();// Method is used to get the value of cf variable of dataStore of VM.
	
	
}
