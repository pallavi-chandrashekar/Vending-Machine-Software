package data_VendingMachine;

public class dataStore_vm2 extends dataStore {
	public static float temp_p, temp_v, price, cf;

	@Override
	public void setTemp_p(int p) {
		// TODO Auto-generated method stub

	}

	@Override
	public int getTemp_p() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setPrice(int price) {
		// TODO Auto-generated method stub

	}

	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setTemp_v(int v) {
		// TODO Auto-generated method stub

	}

	@Override
	public int getTemp_v() {
		return 0;
	}

	@Override
	public void setCF(int cf) {
		// TODO Auto-generated method stub

	}

	@Override
	public int getCF() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setTemp_p1(float p) {
		//Method stores the value passed to temp_p variable dataStore of vm_2.
		temp_p = p;

	}

	@Override
	public float getTemp_p1() {
		// Method is used to get the value of temp_p variable of dataStore of vm_2.

		return temp_p;
	}

	@Override
	public void setPrice1(float p) {

		//Method stores the value passed to price variable dataStore of vm_2.
		price = p;
	}

	@Override
	public float getPrice1() {

		// Method is used to get the value of price variable of dataStore of vm_2
		return price;
	}

	@Override
	public void setTemp_v1(float v) {
		//Method stores the value passed to temp_v variable dataStore of vm_2.
		temp_v = v;
	}

	@Override
	public float getTemp_v1() {

		// Method is used to get the value of temp_v variable of dataStore of vm_2
		return temp_v;
	}

	@Override
	public void setCF1(float cf1) {
		//Method stores the value passed to cf variable dataStore of vm_2.
		cf = cf1;
	}

	@Override
	public float getCF1() {

		// Method is used to get the value of cf variable of dataStore of vm_2
		return cf;
	}

}
