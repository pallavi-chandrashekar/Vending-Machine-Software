package data_VendingMachine;

public class dataStore_vm1 extends dataStore {

	public static int temp_p, temp_v, price, cf; // variables used for vm_1.

	@Override
	public void setTemp_p(int p) {
		//Method stores the value passed to temp_p variable dataStore of vm_1.
		temp_p = p;

	}

	@Override
	public int getTemp_p() {
		// Method is used to get the value of temp_p variable of dataStore of vm_1
		return temp_p;
	}

	@Override
	public void setPrice(int p) {
		//Method stores the value passed to price variable of dataStore of vm_1.
		price = p;
	}

	@Override
	public int getPrice() {

		// Method is used to get the value of price variable of dataStore of vm_1
		return price;
	}

	@Override
	public void setTemp_v(int v) {
		temp_v = v;

	}

	@Override
	public int getTemp_v() {

		// Method is used to get the value of temp_v variable of dataStore of vm_1
		return temp_v;
	}

	@Override
	public void setCF(int cf1) {
		//Method stores the value passed to cf variable dataStore of vm_1.
		cf = cf1;

	}

	@Override
	public int getCF() {
		// Method is used to get the value of cf variable of dataStore of vm_1
		return cf;
	}

	@Override
	public void setTemp_p1(float p) {
		// TODO Auto-generated method stub

	}

	@Override
	public float getTemp_p1() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setPrice1(float price) {
		// TODO Auto-generated method stub

	}

	@Override
	public float getPrice1() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setTemp_v1(float v) {
		// TODO Auto-generated method stub

	}

	@Override
	public float getTemp_v1() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setCF1(float cf) {
		// TODO Auto-generated method stub

	}

	@Override
	public float getCF1() {
		// TODO Auto-generated method stub
		return 0;
	}

}
