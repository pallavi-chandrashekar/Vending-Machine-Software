package statePattern;

import processor_VendingMachine.*;

public class Idle extends abstractStates {

	public Idle(MDAEFSM_VendingMachine MD, outputProcessor_VendingMachine OP) {
		super(MD, OP);
		this.MD = MD;
		this.OP = OP;
	}

	@Override
	public void Create() {
		// TODO Auto-generated method stub

	}

	@Override
	public void Coin(int value) {
		// In this Idle State we will override Coin(int i) method. If I value is 0, then value of cf is changed to cf+I in the dataStore.
		// If I value is 1, then value of cf is changed to cf+I in the dataStore. 
		//A value is set to Zero in MDAEFSM and state is changed to CoinInserted.
		if (value == 0) {
			OP.IncreaseCF();
		} else if (value == 1) {
			OP.IncreaseCF();
			MD.setAtoZero();
			MD.changeState(3);
		}

	}

	@Override
	public void Card() {
		//In this Idle state, we will override Card() method as well. Set cf to zero in dataStore. Changes state to CoinInserted.
		OP.ZeroCF();
		MD.changeState(3);
	}

	@Override
	public void SetPrice() {
		// In this Idle state, we will override SetPrice() method, which Stores sets the value of price in dataStore.
		OP.StorePrice();

	}

	@Override
	public void cancel() {
		// TODO Auto-generated method stub

	}

	@Override
	public void insert_cups(int n) {
		// In this Idle state, we will override insert_cups(int n) method also, we will change the value of k in MDAEFSM to k+n.
		int k;
		if (n > 0) {
			k = MD.getK();
			MD.setK(n+k);
		}

	}

	@Override
	public void Additive(int additional) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose_drink(int drink) {
		// TODO Auto-generated method stub

	}

}
