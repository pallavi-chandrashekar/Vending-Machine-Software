package statePattern;

import processor_VendingMachine.*;

public abstract class abstractStates {
	//This is abstract class of States in vending machine. Here we will execute state pattern

	outputProcessor_VendingMachine OP; // pointer to output processor
	MDAEFSM_VendingMachine MD; //pointer to MDAEFSM

	public abstractStates(MDAEFSM_VendingMachine MD_1, outputProcessor_VendingMachine OP_1) {
		this.MD = MD_1;
		this.OP = OP_1;
	}

	public abstract void Create(); // Abstract Create() method. Which stores the price value to the dataStore associated with vendingmachine and change the state of the machine to NoCups state.

	public abstract void Coin(int i); // abstract Coin(int i) method. If I value is 0, then value of cf is changed to cf+I in the dataStore. If I value is 1, then value of cf is changed to cf+I in the dataStore. A value is set to Zero in MDAEFSM and state is changed to CoinInserted.

	public abstract void Card(); // abstract Card() method as well. Set cf to zero in dataStore. Changes state to CoinInserted.

	public abstract void SetPrice();// abstract SetPrice() method, which Stores sets the value of price in dataStore.

	public abstract void cancel(); // abstract cancel() method, returns the coin, sets cf to zero and changes state to Idle state.

	public abstract void insert_cups(int k);// abstract insert_cups(int n) method. If the value of n is greater than 0, then it stores 0 to cf in the dataStore. Change the value of k in MDAESFM and change the state to Idle.

	public abstract void Additive(int additional); // abstract Additive method.In this method, we will check the value of A[additional] in MDAEFSM, if value is 1, then we will deselect the additive. If value is 0, then we will select the additive.

	public abstract void dispose_drink(int drink); //abstract dispose_drink method. In this Method, if value of k in MDAEFSM is less than or equal to 1, then we will call DisposeDrink in output Processor, we will call DisposeAdditive and change the state to NoCups.
	//If value of k in MDAEFSM is greater than 1, then call DisposeDrink in output Processor, we will call DisposeAdditive, set the value of k to k-1, set cf to zero and change the state to Idle.


}
