package statePattern;

import processor_VendingMachine.*;

public class CoinInserted extends abstractStates {

	public CoinInserted(MDAEFSM_VendingMachine MD, outputProcessor_VendingMachine OP) {
		super(MD, OP);
		this.MD = MD;
		this.OP = OP;
	}

	@Override
	public void Create() {
		// TODO Auto-generated method stub

	}

	@Override
	public void Coin(int i) {
		OP.ReturnCoins();
	}

	@Override
	public void Card() {
		// TODO Auto-generated method stub

	}

	@Override
	public void SetPrice() {
		// TODO Auto-generated method stub

	}

	@Override
	public void cancel() {
		// In CoinInserted state, we will override cancel() method, returns the coin, sets cf to zero and changes state to Idle state.
		OP.ReturnCoins();
		OP.ZeroCF();
		MD.changeState(2);

	}

	@Override
	public void insert_cups(int k) {
		// TODO Auto-generated method stub
	}

	@Override
	public void Additive(int additional) {
		// In this method, we will check the value of A[additional] in MDAEFSM, if value is 1, then we will deselect the additive. 
		//If value is 0, then we will select the additive.
		
		if (MDAEFSM_VendingMachine.A[additional] == 1) {
			MDAEFSM_VendingMachine.updateA(additional, 0);
			// MDAEFSM_VendingMachine.A[additional]=0;
		} else if (MDAEFSM_VendingMachine.A[additional] == 0) {
			MDAEFSM_VendingMachine.updateA(additional, 1);
			// MDAEFSM_VendingMachine.A[additional]=1;
		}

	}

	@Override
	public void dispose_drink(int drink) {

		// In this Method, if value of k in MDAEFSM is less than or equal to 1, then we will call DisposeDrink in output Processor, we will call DisposeAdditive and change the state to NoCups.
		//If value of k in MDAEFSM is greater than 1, then call DisposeDrink in output Processor, we will call DisposeAdditive, set the value of k to k-1, set cf to zero and change the state to Idle.

		int k = MDAEFSM_VendingMachine.k;
		if (k <= 1) {
			// System.out.println("K is "+k);
			OP.DisposeDrink(drink);
			OP.DisposeAdditive(MDAEFSM_VendingMachine.A);
			MD.changeState(1);
		} else if (k > 1) {
			//System.out.println("K is " + k);
			OP.DisposeDrink(drink);
			OP.DisposeAdditive(MDAEFSM_VendingMachine.A);
			MD.setK(k - 1);
			OP.ZeroCF();
			MD.changeState(2);
		}

	}

}
