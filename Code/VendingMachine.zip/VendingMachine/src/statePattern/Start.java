package statePattern;

import processor_VendingMachine.*;

public class Start extends abstractStates {
	// this is Start state class

	public Start(MDAEFSM_VendingMachine MD, outputProcessor_VendingMachine OP) {
		super(MD, OP);
		this.MD = MD;
		this.OP = OP;
	}

	@Override
	public void Create() {
		// In this Start State we will override only Create() method. 
		//Which stores the price value to the dataStore associated with vendingmachine and change the state of the machine to NoCups state.
		OP.StorePrice();
		MD.changeState(1);
	}

	@Override
	public void Coin(int i) {
		// OP.ReturnCoins();
	}

	@Override
	public void Card() {
		// TODO Auto-generated method stub

	}

	@Override
	public void SetPrice() {
		// TODO Auto-generated method stub

	}

	@Override
	public void cancel() {
		// TODO Auto-generated method stub

	}

	@Override
	public void insert_cups(int k) {
		// TODO Auto-generated method stub

	}

	@Override
	public void Additive(int additional) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose_drink(int drink) {
		// TODO Auto-generated method stub

	}

}
