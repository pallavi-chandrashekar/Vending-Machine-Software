package statePattern;

import processor_VendingMachine.*;

public class NoCups extends abstractStates {
	MDAEFSM_VendingMachine MD;
	outputProcessor_VendingMachine OP;

	public NoCups(MDAEFSM_VendingMachine MD, outputProcessor_VendingMachine OP) {
		super(MD, OP);
		this.MD = MD;
		this.OP = OP;
	}

	@Override
	public void insert_cups(int n) {
		// In this NoCups State we will override only insert_cups(int n) method. 
		//If the value of n is greater than 0, then it stores 0 to cf in the dataStore. 
		//Change the value of k in MDAESFM and change the state to Idle.
		if (n > 0) {
			OP.ZeroCF();
			MD.setK(n);
			MD.changeState(2);
		} else {
			System.out.println("Please enter positive value or value greater than zero for no of cups");
		}

	}

	@Override
	public void Additive(int additional) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose_drink(int drink) {
		// TODO Auto-generated method stub

	}

	@Override
	public void Create() {
		// TODO Auto-generated method stub

	}

	@Override
	public void Coin(int i) {
		// TODO Auto-generated method stub

	}

	@Override
	public void Card() {
		// TODO Auto-generated method stub

	}

	@Override
	public void SetPrice() {
		// TODO Auto-generated method stub

	}

	@Override
	public void cancel() {
		// TODO Auto-generated method stub

	}

}
