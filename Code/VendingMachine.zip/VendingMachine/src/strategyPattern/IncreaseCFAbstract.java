package strategyPattern;

import data_VendingMachine.dataStore;

public abstract class IncreaseCFAbstract {

	public abstract void IncreaseCF(dataStore DS);

}
