package strategyPattern;

public class DisposeAdditive_vm1 extends DisposeAdditiveAbstract {

	@Override
	public void DisposeAdditive(int[] a) {

		for (int i = 1; i < a.length; i++) {
			if (a[i] == 1) {
				switch (i) {
				case 1:
					System.out.println("Sugar.");
					break;
				}
			}

		}

	}

}
