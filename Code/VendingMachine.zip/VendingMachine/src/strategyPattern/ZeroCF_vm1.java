package strategyPattern;

import data_VendingMachine.dataStore;

public class ZeroCF_vm1 extends ZeroCFAbstract {

	@Override
	public void ZeroCF(dataStore DS) {
		int cf = 0;
		DS.setCF(cf);

	}

}
