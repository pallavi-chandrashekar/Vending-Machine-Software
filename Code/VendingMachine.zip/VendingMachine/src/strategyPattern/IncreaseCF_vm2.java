package strategyPattern;

import data_VendingMachine.dataStore;

public class IncreaseCF_vm2 extends IncreaseCFAbstract {

	@Override
	public void IncreaseCF(dataStore DS) {
		float v = DS.getTemp_v1();
		float cf = DS.getCF1();
		cf = cf + v;
		DS.setCF1(cf);

	}

}
