package strategyPattern;

import data_VendingMachine.dataStore;

public class StorePrice_vm1 extends StorePriceAbstract {

	@Override
	public void StorePrice(dataStore DS) {
		int p = DS.getTemp_p();
		DS.setPrice(p);
		System.out.println("Price value is set to " + DS.getPrice());

	}

}
