package strategyPattern;

import processor_VendingMachine.outputProcessor_VendingMachine;

public class ReturnCoins_vm2 extends ReturnCoinsAbstract {

	@Override
	public void ReturnCoins() {
		System.out.println("Coins returned " + (outputProcessor_VendingMachine.coinValue_vm2));

	}

}
