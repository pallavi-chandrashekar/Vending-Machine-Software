package strategyPattern;

public abstract class DisposeDrinkAbstract {

	public abstract void DisposeDrink(int drink);

}
