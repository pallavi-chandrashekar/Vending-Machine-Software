package strategyPattern;

import data_VendingMachine.dataStore;

public abstract class ReturnCoinsAbstract {
	dataStore DS;

	public abstract void ReturnCoins();

}
