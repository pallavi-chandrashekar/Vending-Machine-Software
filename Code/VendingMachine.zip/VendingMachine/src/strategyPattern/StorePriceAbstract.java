package strategyPattern;

import data_VendingMachine.dataStore;

public abstract class StorePriceAbstract {

	public abstract void StorePrice(dataStore DS);

}
