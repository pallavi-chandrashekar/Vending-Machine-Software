package strategyPattern;

import data_VendingMachine.dataStore;

public abstract class ZeroCFAbstract {

	public abstract void ZeroCF(dataStore DS);

}
