package strategyPattern;

import data_VendingMachine.dataStore;

public class IncreaseCF_vm1 extends IncreaseCFAbstract {

	@Override
	public void IncreaseCF(dataStore DS) {
		int v = DS.getTemp_v();
		int cf = DS.getCF();
		cf = cf + v;
		DS.setCF(cf);
	}

}
