package strategyPattern;

public class DisposeAdditive_vm2 extends DisposeAdditiveAbstract {

	@Override
	public void DisposeAdditive(int[] a) {

		for (int i = 1; i < a.length; i++) {
			if (a[i] == 1) {
				switch (i) {
				case 2:
					System.out.println("Sugar\n");
					break;

				case 1:
					System.out.println("Cream\n");
					break;

				case 3:
					System.out.println("Sugar and Cream\n");
					break;
				}

			}
		}

	}

}
