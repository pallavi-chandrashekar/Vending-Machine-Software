package strategyPattern;

public class DisposeDrink_vm2 extends DisposeDrinkAbstract {

	@Override
	public void DisposeDrink(int drink) {
		switch (drink) {
		case 1:
			System.out.println("Coffee added with ");
			break;

		}

	}

}
