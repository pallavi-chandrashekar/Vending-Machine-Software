package strategyPattern;

import data_VendingMachine.dataStore;

public class ZeroCF_vm2 extends ZeroCFAbstract {

	@Override
	public void ZeroCF(dataStore DS) {
		float cf = 0;
		DS.setCF1(cf);

	}

}
