package strategyPattern;

public class DisposeDrink_vm1 extends DisposeDrinkAbstract {

	@Override
	public void DisposeDrink(int drink) {
		switch (drink) {
		case 1:
			System.out.println("Tea added with ");
			break;

		case 2:
			System.out.println("Chocolate added with ");
			break;

		}

	}

}
