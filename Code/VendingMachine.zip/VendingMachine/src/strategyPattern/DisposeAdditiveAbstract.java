package strategyPattern;

public abstract class DisposeAdditiveAbstract {

	public abstract void DisposeAdditive(int[] a);

}
