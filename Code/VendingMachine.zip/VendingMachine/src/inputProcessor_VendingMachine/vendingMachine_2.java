package inputProcessor_VendingMachine;

import abstractFactoryPattern.*;
import data_VendingMachine.*;
import processor_VendingMachine.MDAEFSM_VendingMachine;
import processor_VendingMachine.outputProcessor_VendingMachine;

public class vendingMachine_2 {

	dataStore DS;
	MDAEFSM_VendingMachine MD;
	abstractFactory AF;
	float cf, price;

	public void setDataStore() {
		//set MDAEFSM pointer to object created in driver.
		DS = AF.getDataStore();

	}

	public void setAbstractFactory(abstractFactory vm2) {
		// set vm2 factory ponter to object created in driver.
		AF = vm2;

	}

	public dataStore getDataStore() {
		// get datastore for vm2 from abstractfactory.
		
		return DS;
	}

	public void setMDAEFSM(MDAEFSM_VendingMachine MVM) {
		MD = MVM;

	}

	public void CANCEL() {
		// invokes Cancel in MDAEFSM.
		MD.Cancel();

	}

	public void SetPrice(float p) {
		//set temp_p in datastore and invokes set_Price in MDAEFSM with p as parameter.
		DS.setTemp_p1(p);
		MD.set_Price();
	}

	public void InsertCups(int n) {
		// invokes Insert_cups in MDAEFSM with n a parameter and set the value of k in MDAEFSM as value of n.
		MD.Insert_cups(n);
		MD.setK(n);

	}

	public void dispose_drink(int i) {
		//invokes dispose_drink in MDAEFSM with i as parameter.
		MD.dispose_drink(i);

	}

	public void additive(int i) {
		// invokes additive in MDAEFSM with i as parameter.
		MD.additive(i);

	}

	public void COIN(float v) {
		//sets temp_v value as v. Get the value of cf and price and adds cf and v and compare them with price value. 
		//If result is greater than price value, then Coin(1) is invoked in MDAEFSM else Coin(0) is invoked in MDAEFSM.
		DS.setTemp_v1(v);
		cf = DS.getCF1();
		price = DS.getPrice1();

		if ((cf + v) >= price) {
			outputProcessor_VendingMachine.coinValue_vm2 = v;
			MD.coin(1);
		} else {
			outputProcessor_VendingMachine.coinValue_vm2 = v;
			MD.coin(0);
		}
	}

	public void CREATE(float p) {
		// set temp_p and invokes create in MDAEFSM.
		DS.setTemp_p1(p);
		MD.create();
	}

}
