package inputProcessor_VendingMachine;

import abstractFactoryPattern.*;
import data_VendingMachine.*;
import processor_VendingMachine.MDAEFSM_VendingMachine;
import processor_VendingMachine.outputProcessor_VendingMachine;

public class vendingMachine_1 {
	MDAEFSM_VendingMachine MD; // pointer to MDAEFSM class
	abstractFactory AF; // pointer to abstractFactory class
	dataStore DS; // pointer to datastore
	int price, cf; // variables to store values.

	public void setMDAEFSM(MDAEFSM_VendingMachine MVM) {
		//set MDAEFSM pointer to object created in driver.
		MD = MVM;
	}

	public void setAbstractFactory(abstractFactory vm1) {
		// set vm1 factory ponter to object created in driver.
		AF = vm1;
	}

	public void setDataStore() {
		// get datastore for vm1 from abstractfactory.
		DS = AF.getDataStore();
	}

	public dataStore getDataStore() {
		return DS;
	}

	public void create(int p) {
		// set temp_p and invokes create in MDAEFSM.
		DS.setTemp_p(p);
		MD.create();

	}

	public void coin(int v) {
		//set temp_v and get the value of cf and price values from dataStore of vm1 and compare the sum of v and cf with price. 
		
		//If sum value is greater than price then coin is invoked in MDAEFSM with 1 as parameter else coin is invoked in MDAEFSM with 0 as parameter.
	
		DS.setTemp_v(v);
		cf = DS.getCF();
		price = DS.getPrice();

		if ((cf + v) >= price) {
			// outputProcessor_VendingMachine.coinValue_vm1=v;
			outputProcessor_VendingMachine.coinValue_vm1 = cf;
			MD.coin(1);
		} else {
			// outputProcessor_VendingMachine.coinValue_vm1=v;
			outputProcessor_VendingMachine.coinValue_vm1 = cf;
			MD.coin(0);
		}
	}

	public void card(float x) {
		// get the value of price from dataStore of vm1 and compare it with x. 
		//If x is greater than or equal to price then card is invoked in MDAEFSM.
		
		price = DS.getPrice();
		//check for the condition.
		if (x >= price)
			MD.card();
	}

	public void additive(int i) {
		// invokes additive in MDAEFSM with i as parameter.
		MD.additive(i);
	}

	public void dispose_drink(int i) {
		//invokes dispose_drink in MDAEFSM with i as parameter
		MD.dispose_drink(i);

	}

	public void insert_cups(int n) {
		// invokes Insert_cups in MDAEFSM with n a parameter.
		MD.Insert_cups(n);

	}

	public void set_price(int p) {
		//set temp_p in datastore and invokes set_Price in MDAEFSM with p as parameter.
		DS.setTemp_p(p);
		MD.set_Price();

	}

	public void cancel() {
		// invokes Cancel in MDAEFSM.
		MD.Cancel();

	}

}
