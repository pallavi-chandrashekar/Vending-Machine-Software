package inputProcessor_VendingMachine;
/* 
 * 
 * Author : Pallavi Chandrashekar
 */
import java.util.Scanner;

import abstractFactoryPattern.*;
import processor_VendingMachine.*;
import statePattern.*;

public class driver {
	//This is the class where execution of the project starts.

	public static void main(String[] args) {


		driver vm = new driver(); // create an object for vending machine.
		vm.selectMachine(); // calling a method which performs function based on the input.

	}

	void selectMachine() {
		int vm;// variable to read which vm is selected
		boolean flag = true; // variable for a loop.
		do { //loop
			try {
				System.out.println("Welcome to Vending Machine\n");
				System.out.println("Please select the vending machine\n");
				System.out.println("Enter 1 for Vending machine 1.\n");
				System.out.println("Enter 2 for Vending machine 2.\n");

				Scanner sc = new Scanner(System.in);
				vm = sc.nextInt();

				outputProcessor_VendingMachine OP = new outputProcessor_VendingMachine();
				MDAEFSM_VendingMachine MVM = new MDAEFSM_VendingMachine();

				abstractStates abStates[] = new abstractStates[4];
				abStates[0] = new Start(MVM, OP);
				abStates[1] = new NoCups(MVM, OP);
				abStates[2] = new Idle(MVM, OP);
				abStates[3] = new CoinInserted(MVM, OP);
				MVM.setStateList(abStates);

				switch (vm) {
				case 1: // case for vm_1
					System.out.println("You have selected VM_1");
					abstractFactory AF1 = new abstractFactory_vm1();
					OP.setFactory(AF1);
					vm1_functions(AF1, MVM, OP);
					flag = false;
					break;

				case 2: // case for vm_2
					System.out.println("You have selected VM_2");
					abstractFactory AF2 = new abstractFactory_vm2();
					OP.setFactory(AF2);
					vm2_functions(AF2, MVM, OP);
					flag = false;
					break;
					
				default:
					System.out.println("Sorry we have only 2 Vending Machines.\n");
					flag=false;
					break;
				}// end of switch
				sc.close(); // closing the scanner variable.
			}catch(Exception e) {
				System.out.println("Please enter proper input");
				
			}
			// end of catch
			
		} while(flag); // end of loop

	} // end of function

	void vm1_functions(abstractFactory AF1, MDAEFSM_VendingMachine MVM, outputProcessor_VendingMachine OP) {
		//function which vm_1 operations are performed.
		vendingMachine_1 vm1 = new vendingMachine_1(); // object for vendingMachine_1.
		vm1.setMDAEFSM(MVM); //SetMDAEFSM 
		vm1.setAbstractFactory(AF1); // set abstract factory as abstractFactory_vm1.
		vm1.setDataStore(); // set the dataStore as dataStore_1
		// OP.setDataStore(AF1.getDataStore());
		OP.setDataStore();

		int p, v, n, input; // variables used in vm_1
		String ch;
		float x;

		System.out.println("\t\tVending Machine 1\n");
		System.out.println("Menu\n");
		System.out.println("0. create(int)\n");
		System.out.println("1. coin(int)\n");
		System.out.println("2. card(float)\n");
		System.out.println("3. sugar()\n");
		System.out.println("4. tea()\n");
		System.out.println("5. chocolate()\n");
		System.out.println("6. insert_cup(int)\n");
		System.out.println("7. set_price(int)\n");
		System.out.println("8. cancel()\n");

		Scanner reader = new Scanner(System.in);
		ch = "1";
		// MDAEFSM_VendingMachine.setA(1);
		while (!ch.equalsIgnoreCase("q")) {
			
				System.out.println("\n Select Operation: ");
				System.out.println(" 0-create, 1-coin, 2-card, 3-sugar, 4-tea, 5-chocolate, 6-insert_cup, 7-set_price");
				System.out.println(" 8-cancel, q-quit");
				System.out.print(" Enter your choice: ");
				try {

				// ch = (char) reader.next().charAt(0);
				ch = reader.nextLine();

				// input = Character.getNumericValue(ch);

				input = Integer.parseInt(ch);
				//System.out.println("Value " + input);

				switch (input) {

				case 0: {
					// selected create(int).
					System.out.println("Operation Selected is create(int) \n");
					System.out.println("Please enter the value of p\n");

					p = reader.nextInt(); // read int value.
					vm1.create(p);// call create() function in vendingMachine_1

					break;
				}

				case 1: {
					// selected coin(int)
					System.out.println("Operation selected is coin(int) \n");
					System.out.println("Please enter the value of coins (v) \n");

					v = reader.nextInt(); // read int value 
					vm1.coin(v); // call coin() function in vendingMachine_1
					break;
				}
				case 2: {
					// selected card(float)
					System.out.println("Operation selected is card(float) \n");
					System.out.println("Please enter the value to be added (x)\n");
					x = reader.nextFloat(); // read float value
					vm1.card(x); // call card() function in vendingMachine_1
					break;
				}

				case 3: {
					// sugar selected
					System.out.println("Operation selected is sugar()\n");
					vm1.additive(1);// call additive() function in vendingMachine_1
					break;
				}

				case 4: {
					// selected tea()
					System.out.println("Operation selected is tea() \n");
					vm1.dispose_drink(1); // call dispose_drink() function in vendingMachine_1
					break;
				}

				case 5: {
					// selected chocolate()
					System.out.println("Operation selected is chocolate() \n");
					vm1.dispose_drink(2); // call dispose_drink() function in vendingMachine_1
					break;
				}

				case 6: {
					System.out.println("Operation selected is insert_cups() \n");
					System.out.println("Please enter number of cups\n");
					n = reader.nextInt(); // read int value
					vm1.insert_cups(n); // call insert_cups() function in vendingMachine_1
					break;
				}

				case 7: {
					System.out.println("Operation selected is set_price() \n");
					System.out.println("Please enter the value of p\n");
					p = reader.nextInt(); //read int value.
					vm1.set_price(p); // call set_price() function in vendingMachine_1

					break;
				}

				case 8: {
					System.out.println("Operation selected is cancel() \n");
					vm1.cancel(); // call cancel() function in vendingMachine_1
					break;
				}

				default:
					System.out.println("Please enter correct option\n");
					break;
				}
			} catch (Exception e) {
				System.out.print("Please enter Proper value\n");
				continue;
			}// end of catch
		}// end of while
		reader.close();
	}// end of vm_1 function

	void vm2_functions(abstractFactory AF2, MDAEFSM_VendingMachine MVM, outputProcessor_VendingMachine OP) {
		//function which vm_2 operations are performed.
	
		vendingMachine_2 vm2 = new vendingMachine_2(); // object for vendingMachine_2.
		vm2.setMDAEFSM(MVM); //SetMDAEFSM
		vm2.setAbstractFactory(AF2); // set abstract factory as abstractFactory_vm2.
		vm2.setDataStore(); // set the dataStore as dataStore_2
		
		OP.setDataStore(); // set the dataStore as dataStore_2 in output processor

		float p, v; // variables used in vm2.
		int n, input;
		String ch;

		System.out.println("\t\tVending Machine 2\n");
		System.out.println("Menu\n");
		System.out.println("0. CREATE(float)\n");
		System.out.println("1. COIN(float)\n");
		System.out.println("2. SUGAR()\n");
		System.out.println("3. CREAM()\n");
		System.out.println("4. COFFEE()\n");
		System.out.println("5. InsertCups(int)\n");
		System.out.println("6. SetPrice(float)\n");
		System.out.println("7. CANCEL()\n");

		Scanner reader1 = new Scanner(System.in);
		ch = "1";
		while (!ch.equalsIgnoreCase("q")) {
			
				System.out.println("\n Select Operation: ");
				System.out.println(" 0-CREATE, 1-COIN, 2-SUGAR, 3-CREAM, 4-COFFEE, 5-InsertCups, 6-SetPrice, 7-CANCEL");
				System.out.println("q-quit");
				System.out.print(" Enter your choice: ");
				try {
				ch = reader1.nextLine();
				// ch = (char) reader1.next().charAt(0);

				
				input = Integer.parseInt(ch); // parse string to integer.

				switch (input) { 

				case 0:
					// selected CREATE(float).
					System.out.println("Operation Selected is CREATE(float) \n");
					System.out.println("Please enter the value of p\n");
					p = reader1.nextFloat(); // read float value.
					vm2.CREATE(p); // call CREATE() function in vendingMachine_2
					break;

				case 1:
					// selected coin(int)
					System.out.println("Operation selected is COIN(float) \n");
					System.out.println("Please enter the value of coins (v) \n");
					v = reader1.nextFloat();// read float value
					vm2.COIN(v); // call COIN() function in vendingMachine_2
					break;

				case 2:
					// SUGAR selected
					System.out.println("Operation selected is SUGAR()\n");
					vm2.additive(2); // call additive() function in vendingMachine_2
					break;

				case 3:
					// CREAM selected
					System.out.println("Operation selected is CREAM()\n");
					vm2.additive(1); // call additive() function in vendingMachine_2
					break;

				case 4:
					// selected coffee()
					System.out.println("Operation selected is COFFEE() \n");
					vm2.dispose_drink(1); // call dispose_drink() function in vendingMachine_2
					break;

				case 5:
					System.out.println("Operation selected is InsertCups(int) \n");
					System.out.println("Please enter number of cups\n");
					n = reader1.nextInt(); // read int value 
					vm2.InsertCups(n); // call InsertCups() function in vendingMachine_2
					break;

				case 6:
					System.out.println("Operation selected is SetPrice(float) \n");
					System.out.println("Please enter the value of p\n");
					p = reader1.nextFloat(); // read float value 
					vm2.SetPrice(p); // call setPrice() function in vendingMachine_2
					break;

				case 7:
					System.out.println("Operation selected is cancel() \n");
					vm2.CANCEL(); // call CANCEL() function in vendingMachine_2
					break;

				default:
					System.out.println("Please enter correct option\n");
					break;
				} // end of switch
			} // end of try 
			catch (Exception e) {
				System.out.println("Please enter proper input");
				continue;
			}// end of catch
		}
		reader1.close(); // close the scanner object
	}// end of function

}// end of class
